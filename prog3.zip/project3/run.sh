export CC=/usr/bin/clang
export CXX=/usr/bin/clang++
./build.sh
bin/LLVM-Lab $@