
void printf(string fmt, ...);


int main() {
    int a;
    int b;
    int c;
    int d;
    float x;
    float y;
    float z;
    float w;


    a = 5;
    b = 5;
    c = (-a * -b) + 1;
    d = (a/b) - 1;

    d = c % d;

    x = 3.14;
    y = 2.76;
    z = (-x * y) - 1.0;
    w = (x/y) + 1.0;

    w = z % x;

    {
    }


    return 0;
}