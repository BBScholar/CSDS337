
int main() {
    int a;
    int b;
    int c;

    bool x;
    bool y; 
    bool z;
    
    a = 1;
    b = b % 3 + a * 2;
}
