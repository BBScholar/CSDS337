
int a = 1;
void main() {


}
