int main() {
    int i;
    float f;
    bool b;
    string s;

    x = 0;
    x = x + 1;
    
    f = 3.5;
    f = f - 0.1;

    b = false;
    b = not b;

    s = "yeet";

}
