Name: Benjamin Scholar
CaseID: bbs27

Implementation notes:
- The for loop syntax only supports assignment statements in the first and third positions.
- div operator is implemented as an Arith
    - output type is calculate with the Type.max function, same as all other Arith operators
